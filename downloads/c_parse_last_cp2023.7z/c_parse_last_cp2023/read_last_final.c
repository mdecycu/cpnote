#include <stdio.h>
#include <string.h>

int main() {
    // Open the user file for reading
    FILE* user_file = fopen("2b_user_list.txt", "r");
    if (user_file == NULL) {
        perror("Error opening user file");
        return 1;
    }

    char line[100]; // Assuming a maximum line length of 100 characters

    char valid_users[100][20]; // Assuming a maximum of 100 valid users with a length of 20 characters each
    int valid_user_count = 0;

    // Read and store the student numbers from the user file
    while (fgets(line, sizeof(line), user_file)) {
        line[strcspn(line, "\n")] = '\0'; // Remove the newline character
        strcpy(valid_users[valid_user_count], line);
        valid_user_count++;
    }

    // Close the user file
    fclose(user_file);

    // Open the CAD file for reading
    FILE* cad_file = fopen("cad2023_2b_w8.txt", "r");
    if (cad_file == NULL) {
        perror("Error opening CAD file");
        return 1;
    }

    // Read the CAD file line by line
    while (fgets(line, sizeof(line), cad_file)) {
        char* token = strtok(line, " "); // Split the line by space
        if (token != NULL && strstr(token, "cad") == token) {
            // Extract the student number (skip "cad")
            char student_number[20]; // Assuming a maximum length of 20 characters for a student number
            strcpy(student_number, token + 3); // Skip "cad"
            
            // Check if the student number is in the list of valid users
            for (int i = 0; i < valid_user_count; i++) {
                if (strcmp(valid_users[i], student_number) == 0) {
                    printf("%s\n", student_number);
                    break; // No need to continue checking
                }
            }
        }
    }

    // Close the CAD file
    fclose(cad_file);

    return 0;
}
