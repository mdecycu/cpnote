#include <stdio.h>

int main() {
    // Open the user file for reading
    FILE* user_file = fopen("2b_user_list.txt", "r");
    if (user_file == NULL) {
        perror("Error opening user file");
        return 1;
    }

    char line[100]; // Assuming a maximum line length of 100 characters

    // Read and display the file line by line
    while (fgets(line, sizeof(line), user_file)) {
        printf("%s", line);
    }

    // Close the file
    fclose(user_file);

    return 0;
}
