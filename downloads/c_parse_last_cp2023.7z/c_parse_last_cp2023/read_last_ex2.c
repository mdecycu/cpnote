#include <stdio.h>
#include <string.h>

int main() {
    // Open the CAD file for reading
    FILE* cad_file = fopen("cad2023_2b_w8.txt", "r");
    if (cad_file == NULL) {
        perror("Error opening CAD file");
        return 1;
    }

    char line[100]; // Assuming a maximum line length of 100 characters

    // Read the CAD file line by line
    while (fgets(line, sizeof(line), cad_file)) {
        char* token = strtok(line, " "); // Split the line by space
        if (token != NULL && strstr(token, "cad") != NULL) {
            printf("User: %s\n", token);
        }
    }

    // Close the CAD file
    fclose(cad_file);

    return 0;
}
