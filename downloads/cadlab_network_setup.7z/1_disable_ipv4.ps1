# 關閉 IPv4 網路
Disable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip

# 啟用 IPv6 網路
Enable-NetAdapterBinding -Name "*" -ComponentID ms_tcpip6

# 設置 IPv6 網路中的兩個 DNS 伺服器 (hinet)
$dnsServers = "2001:b000:168::1", "2001:b000:168::2"
Set-DnsClientServerAddress -InterfaceAlias "*" -ServerAddresses $dnsServers
