# Poisson3D
Numerical solution of the three-dimensional Poisson equation via the incomplete Cholesky factorization conjugate gradient method
