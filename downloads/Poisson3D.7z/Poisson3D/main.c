/*
 * main.c
 *
 *  Created on: September 25 2018
 *      Author: Derek W. Harrison
 *
 *      This code solves the 3D poisson equation, gam*div(grad(T))+q(x,y,z) = 0,
 *      with fixed boundary conditions.
 *
 */

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#include "export_data.h"
#include "memory_functions.h"
#include "poisson_solver.h"
#include "poisson_solver_helper.h"
#include "user_types.h"

//////////
/*-----------------------------------------------------------------------------------------------*/
void export_data(char* file_name,
                 char* type_data,
                 grid_size_t grid_size,
                 double ***ptr)
{
    /*
     * This function is used to export solver result data to text
     *
     * input    grid_size
     * input    T
     */

    int i,j,k;
    int nx,ny,nz;

    nx = grid_size.nx;
    ny = grid_size.ny;
    nz = grid_size.nz;

      FILE *file;
      file = fopen(file_name,"w");
      if (file != NULL)
      {
        fprintf(file, "%s", type_data);

          for(j=1;j<=ny;j++)
          {
            fprintf(file,"\n\nj = %i\n\n", j);
            for(k=1;k<=nz;k++)
            {
                for(i=1;i<=nx;i++)
                    fprintf(file,"%f\t",ptr[i][j][k]);
                fprintf(file,"\n");
            }
          }
         fclose(file);
      }
      else
      {
        printf("Could not open file");
      }

}
//////////
//////////
/*-----------------------------------------------------------------------------------------------*/
void free_memory_1D_int(int* ptr)
{
    /*
     * Deallocate 1D array of type int
     *
     * input    ptr
     */

    free(ptr);

}


/*-----------------------------------------------------------------------------------------------*/
void free_memory_1D(double* ptr)
{
    /*
     * Deallocate 1D array of type double
     *
     * input    ptr
     */

    free(ptr);

}


/*-----------------------------------------------------------------------------------------------*/
void free_memory_2D(double** ptr, int nx)
{
    /*
     * Deallocate 2D array of type double
     *
     * input    ptr
     * input    nx
     */

    int i;

    for(i = 0; i < nx; i++)
        free(ptr[i]);

    free(ptr);

}


/*-----------------------------------------------------------------------------------------------*/
void free_memory_3D(double*** ptr, int nx, int ny)
{
    /*
     * Deallocate 3D array of type double
     *
     * input    ptr
     * input    nx
     * input    ny
     */

    int i,j;

    for(i = 0; i < nx; i++)
        for(j = 0; j < ny; j++)
            free(ptr[i][j]);

    for ( i = 0; i < nx; i++)
        free(ptr[i]);

    free(ptr);

}


/*-----------------------------------------------------------------------------------------------*/
int *matrix1D_int(int nx)
{
    /*
     * Allocate 1D array of type int
     *
     * input    nx
     *
     * return   m
     */

    int *m = (int *) calloc(nx, sizeof(int));

    if(!m)
    {
        printf("Unable to allocate memory for 1D array of type int\n");
        exit(1);
    }

    return m;

}


/*-----------------------------------------------------------------------------------------------*/
double *matrix1D(int nx)
{
    /*
     * Allocate 1D array of type double
     *
     * input    nx
     *
     * return   m
     */

    double *m = (double *) calloc(nx, sizeof(double));

    if(!m)
    {
        printf("Unable to allocate memory for 1D array of type double\n");
        exit(1);
    }

    return m;

}


/*-----------------------------------------------------------------------------------------------*/
double **matrix2D( int nx, int ny)
{
    /*
     * Allocate 2D array of type double
     *
     * input    nx
     * input    ny
     *
     * return   m
     */

    int i;

    double **m = (double **) calloc ( nx, sizeof( double *));

    if(!m)
    {
        printf("Unable to allocate memory for 2D array of type double\n");
        exit(1);
    }

    for ( i = 0; i < nx; i++)
    {
        m[i] = (double *) calloc ( ny, sizeof( double));

        if(!m[i])
        {
            printf("Unable to allocate memory for 2D array of type double\n");
            exit(2);
        }
    }

    return m;

}


/*-----------------------------------------------------------------------------------------------*/
double ***matrix3D( int nx, int ny, int nz)
{
    /*
     * Allocate 3D array of type double
     *
     * input    nx
     * input    ny
     * input    nz
     *
     * return   m
     */

    int i,j;

    double ***m = (double ***) calloc ( nx, sizeof(double **));

    for ( i = 0; i < nx; i++)
    {
        m[i] = (double **) calloc ( ny, sizeof(double *));

        if(!m[i])
        {
            printf("Unable to allocate memory for 3D array of type double\n");
            exit(2);
        }
    }

    for(i = 0; i < nx; i++)
        for(j = 0; j < ny; j++)
        {
            m[i][j] = (double *) calloc(nz, sizeof(double));

            if(!m[i][j])
            {
             printf("Unable to allocate memory for 3D array of type double\n");
             exit(3);
            }
        }

    return m;

}


/*-----------------------------------------------------------------------------------------------*/
grid_coordinates_t* allocate_mem_grid_coordinates(int nx, int ny, int nz)
{
    /*
     * Allocate memory for 3D grid coordinates.
     *
     * input    x
     * input    y
     * input    z
     *
     * return   grid_coordinates
     */

    grid_coordinates_t* grid_coordinates = malloc(sizeof(grid_coordinates_t));
    grid_coordinates->X                     = matrix3D(nx, ny, nz);
    grid_coordinates->Y                     = matrix3D(nx, ny, nz);
    grid_coordinates->Z                     = matrix3D(nx, ny, nz);

    return grid_coordinates;

}


/*-----------------------------------------------------------------------------------------------*/
void free_grid_coordinates(grid_coordinates_t* grid_coordinates, int nx, int ny)
{
    /*
     * Deallocate memory used for grid coordinates
     *
     * input    grid_coordinates
     * input    nx
     * input    ny
     */

    free_memory_3D(grid_coordinates->X, nx, ny);
    free_memory_3D(grid_coordinates->Y, nx, ny);
    free_memory_3D(grid_coordinates->Z, nx, ny);
    free(grid_coordinates);

}

/////////
/////////
/*-----------------------------------------------------------------------------------------------*/
void poisson_solver(domain_size_t domain_size,
                    fixed_boundaries_t fixed_boundaries,
                    grid_size_t grid_size,
                    double gamma,
                    double (*source)(double x,double y,double z),
                    grid_coordinates_t* grid_coordinates,
                    double ***T)
{
    /*
     * This function solves the 3D poisson equation gamma*div(grad(T))+q(x,y,z) = 0
     * with fixed boundary conditions.
     *
     * The equation is solved using a preconditioned conjugate gradient method with
     * incomplete cholesky factorization as preconditioner.
     *
     * Note: a node numbering scheme was used such that the first element of all
     * arrays start at 1 as opposed to zero. The numbering scheme used in this work is
     *
     * nn = i + (j-1)*nx + (k-1)*nx*ny
     *
     * where nn is the node number, nx the number of nodes used in the x direction,
     * ny the number of nodes used in the y direction and i, j, k are indices ranging
     * from 1 to nt where nt is the total number of nodes in the 3D grid, i.e.: nt = nx*ny*nz
     * with nz the number of nodes in the z direction.
     *
     * input     domain_size
     * input     grid_size
     * input     fixed_boundaries
     * input     gamma
     * input     source(x,y,z)
     * output    grid_coordinates
     * output    T
     */

    double epsilon, delold, delnew, pAp, error;
    double alpha, B;
    double **A, **L, *Ap, *y, *z, *p, *x, *r;
    int nn, nt, i, j, k, it, imax;

    /*Timing solver*/
    clock_t begin, end;
    double time_spent;
    begin = clock();

    /*Setting variables and coefficients*/
    imax  = 5000;         //Maximum iterations ICCG
    error = 1e-30;        //Tolerance

    nt = grid_size.nx*grid_size.ny*grid_size.nz;

    /*Allocating memory for computation*/
    A         = matrix2D(nt+1,4+1);
    L         = matrix2D(nt+1,4+1);
    y         = matrix1D(nt+1);
    z         = matrix1D(nt+1);
    p         = matrix1D(nt+1);
    Ap        = matrix1D(nt+1);
    x         = matrix1D(nt+1);
    r         = matrix1D(nt+1);

    /*Initial guess x*/
    for (j = 1; j <= nt; j++)
        x[j] = 0.0;

    /*Generate coefficient matrix*/
    generate_coefficient_matrix(domain_size,
                                fixed_boundaries,
                                grid_size,
                                gamma,
                                source,
                                x,
                                grid_coordinates,
                                r,
                                A);

    /*ICCG preconditioning*/
    // Incomplete Cholesky factorization of coefficient matrix A
    incomplete_cholesky_factorization(grid_size, A, L);

    //Solving Ly=r (y = L'z)
    Ly_solver(grid_size, L, r, y);

    //Solving L'z=y
    LTz_solver(grid_size, L, y, p);

    //epsilon = r'*r;
    dot_product(r, r, nt, &epsilon);

    /*Solver iterations*/
    it = 0;
    do
    {
        //delold = r'*z
        dot_product(r, p, nt, &delold);

        //Calculating A*p
        mat_vec_mult(grid_size, A, p, Ap);

        //p'*Ap
        dot_product(p, Ap, nt, &pAp);

        alpha = delold/pAp;

        //x = x+alpha*p;
        vector_addition(x, 1.0, p, alpha, nt, x);

        //r = r-alpha*Ap;
        vector_addition(r, 1.0, Ap, -alpha, nt, r);

        //Solving Ly=r (y = L'z)
        Ly_solver(grid_size, L, r, y);

        //Solving L'z=y
        LTz_solver(grid_size, L, y, z);

        //delnew = r'*z
        dot_product(r, z, nt, &delnew);

        B = delnew/delold;

        //p = z + B*p;
        vector_addition(z, 1.0, p, B, nt, p);

        //r'*r
        dot_product(r, r, nt, &epsilon);

        epsilon = sqrt(epsilon/nt);
        it = it + 1;
    }while (it < imax && epsilon > error);

    /*Processing results*/
    for (i=1;i<=grid_size.nx;i++)
    for (j=1;j<=grid_size.ny;j++)
    for (k=1;k<=grid_size.nz;k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        T[i][j][k] = x[nn];
    }

    /*Freeing memory*/
    free_memory_1D(Ap);
    free_memory_1D(y);
    free_memory_1D(z);
    free_memory_1D(p);
    free_memory_1D(x);
    free_memory_1D(r);
    free_memory_2D(A, nt);
    free_memory_2D(L, nt);

    /*Print out some results*/
    end = clock();
    time_spent = (double)(end - begin)/CLOCKS_PER_SEC;

    printf("error: %E\n",epsilon);
    printf("iterations: %d\n", it);
    printf("running time: %f\n", time_spent);
}
/////////
/////////
/*-----------------------------------------------------------------------------------------------*/
void vector_addition(double *v1,
                     double factor_v1,
                     double *v2,
                     double factor_v2,
                     int size_vector,
                     double *output_vector)
{
    /*
     * Addition of vectors of type double
     *
     * input    v1
     * input    factor_v1
     * input    v2
     * input    factor_v2
     * input    size_vector
     * output   output_vector
     */

    int j;

    for (j=1;j<=size_vector;j++)
        output_vector[j] = factor_v1*v1[j] + factor_v2*v2[j];

}


/*-----------------------------------------------------------------------------------------------*/
void dot_product(double *v1,
                 double *v2,
                 int size_vec,
                 double *dot_product)
{
    /*
     * Calculating the dot product of two vectors of type double
     *
     * input    v1
     * input    v2
     * input    size_vec
     * output   dotproduct
     */

    int j;

    double dummy = 0.0;
    for (j = 1; j <= size_vec; j++)
        dummy = dummy + v1[j]*v2[j];

    *dot_product = dummy;

}


/*-----------------------------------------------------------------------------------------------*/
void mat_vec_mult(grid_size_t grid_size,
                  double** A,
                  double* p,
                  double* Ap)
{
    /*
     * Calculating the matrix product A*p where A is the vectorized coefficient matrix
     * and p a vector
     *
     * input    grid_size
     * input    A
     * input    p
     * output   Ap
     */

    int j, nt;

    nt = grid_size.nx*grid_size.ny*grid_size.nz;

    Ap[1] = A[1][4]*p[1] + A[2][3]*p[2] + A[1+grid_size.nx][2]*p[1+grid_size.nx] +
            A[1+grid_size.nx*grid_size.ny][1]*p[1+grid_size.nx*grid_size.ny];

    for (j = 2; j <= grid_size.nx; j++)
        Ap[j] = A[j][3]*p[j-1] + A[j][4]*p[j] + A[j+1][3]*p[j+1] +
        A[j+grid_size.nx][2]*p[j+grid_size.nx] +
        A[j+grid_size.nx*grid_size.ny][1]*p[j+grid_size.nx*grid_size.ny];

    for (j = grid_size.nx + 1; j <= grid_size.nx*grid_size.ny; j++)
        Ap[j] = A[j][2]*p[j-grid_size.nx] + A[j][3]*p[j-1] + A[j][4]*p[j] +
        A[j+1][3]*p[j+1] + A[j+grid_size.nx][2]*p[j+grid_size.nx] +
        A[j+grid_size.nx*grid_size.ny][1]*p[j+grid_size.nx*grid_size.ny];

    for (j = grid_size.nx*grid_size.ny + 1; j <= nt - grid_size.nx*grid_size.ny; j++)
        Ap[j] = A[j][1]*p[j-grid_size.nx*grid_size.ny] + A[j][2]*p[j-grid_size.nx] +
        A[j][3]*p[j-1] + A[j][4]*p[j] + A[j+1][3]*p[j+1] + A[j+grid_size.nx][2]*p[j+grid_size.nx] +
        A[j+grid_size.nx*grid_size.ny][1]*p[j+grid_size.nx*grid_size.ny];

    for (j = nt - grid_size.nx*grid_size.ny + 1; j <= nt - grid_size.nx; j++)
        Ap[j] = A[j][1]*p[j-grid_size.nx*grid_size.ny] + A[j][2]*p[j-grid_size.nx] +
        A[j][3]*p[j-1] + A[j][4]*p[j] + A[j+1][3]*p[j+1] +
        A[j+grid_size.nx][2]*p[j+grid_size.nx];

    for (j = nt - grid_size.nx + 1; j <= nt - 1; j++)
        Ap[j] = A[j][1]*p[j-grid_size.nx*grid_size.ny] + A[j][2]*p[j-grid_size.nx] +
        A[j][3]*p[j-1] + A[j][4]*p[j] + A[j+1][3]*p[j+1];

    Ap[nt] = A[nt][1]*p[nt-grid_size.nx*grid_size.ny] + A[nt][2]*p[nt-grid_size.nx] +
             A[nt][3]*p[nt-1] + A[nt][4]*p[nt];

}


/*-----------------------------------------------------------------------------------------------*/
void generate_coefficient_matrix(domain_size_t domain_size,
                                 fixed_boundaries_t fixed_boundaries,
                                 grid_size_t grid_size,
                                 double gamma,
                                 double (*source)(double x,double y,double z),
                                 double* x_guess,
                                 grid_coordinates_t* grid_coordinates,
                                 double* r,
                                 double** A)
{
    /*
     * Generated the vectorized coefficient matrix for the poisson solver
     *
     * input    domain_size
     * input    grid_size
     * input    fixed_boundaries
     * input    gamma
     * input    source
     * output   grid_coordinates
     * output   r
     * output   A
     */

    double deltax, deltay, deltaz;
    double a1, a2, a3, a4, a5, a6, a7, a8;
    double b1, b2, b3;
    int nn;

    int i,j,k;

    deltax = domain_size.Lx/grid_size.nx;
    deltay = domain_size.Ly/grid_size.ny;
    deltaz = domain_size.Lz/grid_size.nz;

    b1 = -gamma/(deltax*deltax);
    b2 = -gamma/(deltay*deltay);
    b3 = -gamma/(deltaz*deltaz);

    a1 = -3*b1 - 3*b2 - 3*b3;
    a2 = -2*b1 - 3*b2 - 3*b3;
    a3 = -3*b1 - 2*b2 - 3*b3;
    a4 = -2*b1 - 2*b2 - 3*b3;
    a5 = -3*b1 - 3*b2 - 2*b3;
    a6 = -2*b1 - 3*b2 - 2*b3;
    a7 = -3*b1 - 2*b2 - 2*b3;
    a8 = -2*b1 - 2*b2 - 2*b3;

    /*Generating node coordinates*/
    for (i = 1; i <= grid_size.nx; i++)
    for (j = 1; j <= grid_size.ny; j++)
    for (k = 1; k <= grid_size.nz; k++)
    {
        grid_coordinates->X[i][j][k] = i*deltax-deltax/2;
        grid_coordinates->Y[i][j][k] = j*deltay-deltay/2;
        grid_coordinates->Z[i][j][k] = k*deltaz-deltaz/2;
    }

    /*Generating vectorized coefficient matrix*/
    //Generating central coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1]=b3;
        A[nn][2]=b2;
        A[nn][3]=b1;
        A[nn][4]=a8;
        r[nn]= source(grid_coordinates->X[i][j][k],
                      grid_coordinates->Y[i][j][k],
                      grid_coordinates->Z[i][j][k]) -
              (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
               b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] +
               b2*x_guess[nn+grid_size.nx] + b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating corner 1 coefficients
    for (i = 1; i <= 1; i++)
    for (j = 1; j <= 1; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = 0;
        A[nn][3] = 0;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b2*fixed_boundaries.Ts -
                 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side a cofficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = 1; j <= 1; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = 0;
        A[nn][3] = b1;
        A[nn][4] = a2;
        r[nn] = -2*b2*fixed_boundaries.Ts - 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] +
                 b2*x_guess[nn+grid_size.nx] + b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating corner 2 coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = 1; j <= 1; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = 0;
        A[nn][3] = b1;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Te - 2*b2*fixed_boundaries.Ts -
                 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side d coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = b2;
        A[nn][3] = 0;
        A[nn][4] = a3;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b2*x_guess[nn-grid_size.nx] + A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] +
                 b2*x_guess[nn+grid_size.nx] + b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating face E coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a4;
        r[nn] = -2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b2*x_guess[nn-grid_size.nx] + b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] +
                 b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side b coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a3;
        r[nn] = -2*b1*fixed_boundaries.Te - 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b2*x_guess[nn-grid_size.nx] + b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] +
                 b2*x_guess[nn+grid_size.nx] + b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating corner 4 coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = b2;
        A[nn][3] = 0;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b2*fixed_boundaries.Tn -
                 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b2*x_guess[nn-grid_size.nx] + A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side c coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a2;
        r[nn] = -2*b2*fixed_boundaries.Tn - 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b2*x_guess[nn-grid_size.nx] + b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] +
                 b1*x_guess[nn+1] + b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating corner 3 coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = 1; k <= 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = 0;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Te - 2*b2*fixed_boundaries.Tn -
                 2*b3*fixed_boundaries.Tb +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b2*x_guess[nn-grid_size.nx] + b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side e coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = 1; j <= 1; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = 0;
        A[nn][3] = 0;
        A[nn][4] = a5;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b2*fixed_boundaries.Ts +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + A[nn][4]*x_guess[nn] +
                 b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating face A coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = 1; j <= 1; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = 0;
        A[nn][3] = b1;
        A[nn][4] = a6;
        r[nn] = -2*b2*fixed_boundaries.Ts +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b1*x_guess[nn-1] +
                 A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side f coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = 1; j <= 1; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = 0;
        A[nn][3] = b1;
        A[nn][4] = a5;
        r[nn] = -2*b1*fixed_boundaries.Te - 2*b2*fixed_boundaries.Ts +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b1*x_guess[nn-1] +
                 A[nn][4]*x_guess[nn] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating face D coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = 0;
        A[nn][4] = a7;
        r[nn] = -2*b1*fixed_boundaries.Tw +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating face B coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a7;
        r[nn] = -2*b1*fixed_boundaries.Te +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b2*x_guess[nn+grid_size.nx] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side h coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = 0;
        A[nn][4] = a5;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b2*fixed_boundaries.Tn +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating face C coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a6;
        r[nn] = -2*b2*fixed_boundaries.Tn +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating side g coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = 2; k <= grid_size.nz - 1; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a5;
        r[nn] = -2*b1*fixed_boundaries.Te - 2*b2*fixed_boundaries.Tn +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] +
                 b3*x_guess[nn+grid_size.nx*grid_size.ny]);
    }

    //Generating corner 5 coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = 1; j <= 1; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = 0;
        A[nn][3] = 0;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b2*fixed_boundaries.Ts -
                 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + A[nn][4]*x_guess[nn] +
                 b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx]);
    }

    //Generating side i coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = 1; j <= 1; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = 0;
        A[nn][3] = b1;
        A[nn][4] = a2;
        r[nn] = -2*b2*fixed_boundaries.Ts - 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b1*x_guess[nn-1] +
                 A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx]);
    }

    //Generating corner 6 coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = 1; j <= 1; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = 0;
        A[nn][3] = b1;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Te - 2*b2*fixed_boundaries.Ts -
                 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b1*x_guess[nn-1] +
                 A[nn][4]*x_guess[nn] + b2*x_guess[nn+grid_size.nx]);
    }

    //Generating side l coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = 0;
        A[nn][4] = a3;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] + b2*x_guess[nn+grid_size.nx]);
    }

    //Generating face F coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a4;
        r[nn] = -2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b1*x_guess[nn+1] +
                 b2*x_guess[nn+grid_size.nx]);
    }

    //Generating side j coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = 2; j <= grid_size.ny - 1; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a3;
        r[nn] = -2*b1*fixed_boundaries.Te - 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b2*x_guess[nn+grid_size.nx]);
    }

    //Generating corner 8 coefficients and source terms
    for (i = 1; i <= 1; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = 0;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Tw - 2*b2*fixed_boundaries.Tn -
                 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 A[nn][4]*x_guess[nn] + b1*x_guess[nn+1]);
    }

    //Generating side k coefficients and source terms
    for (i = 2; i <= grid_size.nx - 1; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a2;
        r[nn] = -2*b2*fixed_boundaries.Tn - 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 b1*x_guess[nn-1] + A[nn][4]*x_guess[nn] + b1*x_guess[nn+1]);
    }

    //Generating corner 7 coefficients and source terms
    for (i = grid_size.nx; i <= grid_size.nx; i++)
    for (j = grid_size.ny; j <= grid_size.ny; j++)
    for (k = grid_size.nz; k <= grid_size.nz; k++)
    {
        nn = i + (j-1)*grid_size.nx + (k-1)*grid_size.nx*grid_size.ny;
        A[nn][1] = b3;
        A[nn][2] = b2;
        A[nn][3] = b1;
        A[nn][4] = a1;
        r[nn] = -2*b1*fixed_boundaries.Te -2*b2*fixed_boundaries.Tn -
                 2*b3*fixed_boundaries.Tt +
                 source(grid_coordinates->X[i][j][k],
                        grid_coordinates->Y[i][j][k],
                        grid_coordinates->Z[i][j][k]) -
                (b3*x_guess[nn-grid_size.nx*grid_size.ny] + b2*x_guess[nn-grid_size.nx] +
                 b1*x_guess[nn-1] + A[nn][4]*x_guess[nn]);
    }

}


/*-----------------------------------------------------------------------------------------------*/
void Ly_solver(grid_size_t grid_size,
               double** L,
               double* r,
               double* y)
{
    /*
     * Solves the linear system Lz = r where L is lower triangular
     *
     * input    grid_size
     * input    L
     * input    r
     * output   y
     */

    int j, nt;

    nt = grid_size.nx*grid_size.ny*grid_size.nz;

    y[1]=r[1]/L[1][4];
    for (j = 2; j <= grid_size.nx; j++)
        y[j]=(r[j]-L[j][3]*y[j-1])/L[j][4];

    for (j = grid_size.nx + 1; j <= grid_size.nx*grid_size.ny; j++)
        y[j]=(r[j] - L[j][2]*y[j-grid_size.nx] - L[j][3]*y[j-1])/L[j][4];

    for (j = grid_size.nx*grid_size.ny + 1; j <= nt; j++)
        y[j]=(r[j] - L[j][1]*y[j-grid_size.nx*grid_size.ny] -
                L[j][2]*y[j-grid_size.nx] - L[j][3]*y[j-1])/L[j][4];

}


/*-----------------------------------------------------------------------------------------------*/
void LTz_solver(grid_size_t grid_size,
                double** L,
                double* y,
                double* z)
{
    /*
     * Solves the linear system L'y = z where L' is upper triangular
     *
     * input    grid_size
     * input    L
     * input    y
     * output   z
     */

    int j, nt;

    nt = grid_size.nx*grid_size.ny*grid_size.nz;

    z[nt] = y[nt]/L[nt][4];
    for(j = nt - 1; j >= nt - grid_size.nx + 1; j--)
        z[j] = (y[j] - L[j+1][3]*z[j+1])/L[j][4];

    for(j = nt - grid_size.nx; j >= nt - grid_size.nx*grid_size.ny + 1; j--)
        z[j] = (y[j] - L[j+1][3]*z[j+1] - L[j+grid_size.nx][2]*z[j+grid_size.nx])/L[j][4];

    for(j = nt - grid_size.nx*grid_size.ny; j >= 1; j--)
        z[j] = (y[j] - L[j+1][3]*z[j+1] - L[j+grid_size.nx][2]*z[j+grid_size.nx] -
                L[j+grid_size.nx*grid_size.ny][1]*z[j+grid_size.nx*grid_size.ny])/L[j][4];

}


/*-----------------------------------------------------------------------------------------------*/
void incomplete_cholesky_factorization(grid_size_t grid_size,
                                       double** A,
                                       double** L)
{
    /*
     * Performs the incomplete cholesky factorization on vectorized matrix A
     *
     * input    grid_size
     * input    A
     * output   L
     */

    int i, j, nt;

    nt = grid_size.nx*grid_size.ny*grid_size.nz;

    L[1][1] = 0;
    L[1][2] = 0;
    L[1][3] = 0;
    L[1][4] = sqrt(A[1][4]);

    for (j = 2; j <= nt; j++)
    for (i = 1; i <= 4; i++)
        if (A[j][i] != 0)
        {
            if (j>=1+grid_size.nx*grid_size.ny)
                L[j][1]=A[j][1]/L[j-grid_size.nx*grid_size.ny][4];
            if (j>=1+grid_size.nx)
                L[j][2]=A[j][2]/L[j-grid_size.nx][4];
            L[j][3]=A[j][3]/L[j-1][4];
            L[j][4]=sqrt(A[j][4] - L[j][1]*L[j][1] - L[j][2]*L[j][2] - L[j][3]*L[j][3]);
        }

}
//////////

/*-----------------------------------------------------------------------------------------------*/
static double source_equation(double x,double y,double z)
{
    /*
     * This function specifies the source equation q in the poisson equation
     * gam*div(grad(T))+q(x,y,z) = 0
     *
     * The function can depend on x, y and z coordinates.
     *
     * input    x
     * input    y
     * input    z
     */

    return -sin(M_PI*x) * sin(M_PI*y) * sin(M_PI*z);

}


/*-----------------------------------------------------------------------------------------------*/
int main(int argc, char *argv[])
{
    /*
     * The main function of the poisson solver.
     * Parameters and boundary conditions are specified here
     */

    double                         gamma = 0.0;
    bool                      exportData = FALSE;
    domain_size_t            domain_size = {0};
    grid_size_t                grid_size = {0};
    fixed_boundaries_t  fixed_boundaries = {0};
    grid_coordinates_t* grid_coordinates = NULL;
    double***                          T = NULL;

    /*Set parameters and boundary conditions*/
    domain_size.Lx = 1.0;                   //length of domain along x coordinate
    domain_size.Ly = 1.0;                   //length of domain along y coordinate
    domain_size.Lz = 1.0;                   //length of domain along z coordinate

    grid_size.nx = 10;                       //amount of nodes along x coordinate
    grid_size.ny = 10;                       //amount of nodes along y coordinate
    grid_size.nz = 10;                       //amount of nodes along z coordinate

    gamma = 1.0;                            //poisson equation constant

    fixed_boundaries.Tw = 0.0;              //west face boundary condition
    fixed_boundaries.Te = 0.0;              //east face boundary condition
    fixed_boundaries.Ts = 0.0;              //south face boundary condition
    fixed_boundaries.Tn = 0.0;              //north face boundary condition
    fixed_boundaries.Tb = 0.0;              //bottom face boundary condition
    fixed_boundaries.Tt = 0.0;              //top face boundary condition

    exportData = TRUE;                      //data export guard


    /*Allocating memory for output of poisson solver*/
    grid_coordinates = allocate_mem_grid_coordinates(grid_size.nx+1, grid_size.ny+1, grid_size.nz+1);
    T = matrix3D(grid_size.nx+1, grid_size.ny+1, grid_size.nz+1);

    /*Calling poisson solver*/
    poisson_solver(domain_size,
                   fixed_boundaries,
                   grid_size,
                   gamma,
                   source_equation,
                   grid_coordinates,
                   T);

    /*Exporting data*/
    if(exportData)
    {
        export_data("Poisson3D.txt", "Temperature profile", grid_size, T);
        export_data("GridX.txt", "X grid coordinates", grid_size, grid_coordinates->X);
        export_data("GridY.txt", "Y grid coordinates", grid_size, grid_coordinates->Y);
        export_data("GridZ.txt", "Z grid coordinates", grid_size, grid_coordinates->Z);
    }

    /*Deallocate memory*/
    free_grid_coordinates(grid_coordinates, grid_size.nx+1, grid_size.ny+1);
    free_memory_3D(T, grid_size.nx+1, grid_size.ny+1);

    return 0;

}

