/*
列出由學員填回的各組名單與期望分數, 已經將未填分數的
41127151
41223124
41223127 
補上 60 分
但第一階段只列出有填組別的學員, 因此漏掉以上 3 位學員
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_STUDENTS 100

// 利用 struct 資料結構表示 Student
typedef struct {
    int stud_num;
    int score;
    int group_num;
} Student;

int main() {
    Student students[MAX_STUDENTS];
    int num_students = 0;

    // 讀取檔案
    FILE *file = fopen("cp2023_1a_midterm.txt", "r");
    if (file == NULL) {
        printf("檔案無法開啟\n");
        return 1;
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        if (num_students >= MAX_STUDENTS) {
            printf("資料過多，超出設定\n");
            break;
        }

        // 使用 \t 分割行
        char *token = strtok(line, "\t");
        students[num_students].stud_num = atoi(token);
        token = strtok(NULL, "\t");
        students[num_students].score = atoi(token);
        token = strtok(NULL, "\t");
        students[num_students].group_num = atoi(token);

        num_students++;
    }

    fclose(file);

    // 找出最大的組別編號
    int max_group = 0;
    for (int i = 0; i < num_students; i++) {
        if (students[i].group_num > max_group) {
            max_group = students[i].group_num;
        }
    }

    // 列出同一組組員名單
    for (int group = 1; group <= max_group; group++) {
        printf("第 %d 組的組員名單:\n", group);
        for (int i = 0; i < num_students; i++) {
            if (students[i].group_num == group) {
                printf("學號: %d, 分數: %d\n", students[i].stud_num, students[i].score);
            }
        }
        printf("\n");
    }

    return 0;
}
