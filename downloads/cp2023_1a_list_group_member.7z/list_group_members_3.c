/*
各組補滿九人後
列出各組平均分數
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define MAX_STUDENTS 100
#define MAX_GROUP_SIZE 9

// 利用 struct 資料結構表示 Student
typedef struct {
    int stud_num;
    int score;
    int group_num;
} Student;

int main() {
    Student students[MAX_STUDENTS];
    int num_students = 0;

    // 讀取檔案
    FILE *file = fopen("cp2023_1a_midterm.txt", "r");
    if (file == NULL) {
        printf("檔案無法開啟\n");
        return 1;
    }

    char line[256];
    while (fgets(line, sizeof(line), file)) {
        if (num_students >= MAX_STUDENTS) {
            printf("資料過多，超出設定\n");
            break;
        }

        // 使用 \t 分割行
        char *token = strtok(line, "\t");
        students[num_students].stud_num = atoi(token);
        token = strtok(NULL, "\t");
        students[num_students].score = atoi(token);
        token = strtok(NULL, "\t");
        students[num_students].group_num = atoi(token);

        num_students++;
    }

    fclose(file);

    // 找出最大的組別編號
    int max_group = 0;
    for (int i = 0; i < num_students; i++) {
        if (students[i].group_num > max_group) {
            max_group = students[i].group_num;
        }
    }

    // 隨機分配未滿9人的組別
    for (int group = 1; group <= max_group; group++) {
        int group_count = 0; // 統計每組人數
        for (int i = 0; i < num_students; i++) {
            if (students[i].group_num == group) {
                group_count++;
            }
        }

        if (group_count < MAX_GROUP_SIZE) {
            int remaining_students = MAX_GROUP_SIZE - group_count;
            int available_students[num_students];
            int available_count = 0;

            for (int i = 0; i < num_students; i++) {
                if (students[i].group_num == 0) {
                    available_students[available_count] = i;
                    available_count++;
                }
            }

            for (int i = 0; i < remaining_students && available_count > 0; i++) {
                int random_index = rand() % available_count;
                students[available_students[random_index]].group_num = group;
                available_students[random_index] = available_students[available_count - 1];
                available_count--;
            }
        }
    }

    // 列出同一組的學員名單和分數
    for (int group = 1; group <= max_group; group++) {
        printf("第 %d 組的學員名單:\n", group);
        int group_total_score = 0;
        int group_member_count = 0;

        for (int i = 0; i < num_students; i++) {
            if (students[i].group_num == group) {
                printf("學號: %d, 分數: %d\n", students[i].stud_num, students[i].score);
                group_total_score += students[i].score;
                group_member_count++;
            }
        }

        if (group_member_count > 0) {
            double group_average_score = (double)group_total_score / group_member_count;
            printf("第 %d 組的平均分數: %.2lf\n", group, group_average_score);
        } else {
            printf("第 %d 組無學員\n", group);
        }

        printf("\n");
    }

    return 0;
}
