#include <stdio.h>
#include <gd.h>
#include <math.h>

// Declare the rotation function
void rotateFilledPolygon(int x_orig, int y_orig, double rotation_ang, gdPoint *points, int num_points) {
    int i;
    double angle_rad = rotation_ang * M_PI / 180.0;

    for (i = 0; i < num_points; i++) {
        double x = points[i].x - x_orig;
        double y = points[i].y - y_orig;

        points[i].x = x_orig + x * cos(angle_rad) - y * sin(angle_rad);
        points[i].y = y_orig + x * sin(angle_rad) + y * cos(angle_rad);
    }
}

void draw_star(gdImagePtr img, int x, int y, int size, int color, int rotation, gdPoint *points, int num_points) {
    double deg = M_PI / 180.0;

    for (int i = 0; i < num_points; i++) {
        double angle = M_PI / 2 + i * 2 * M_PI / 10 + rotation * deg;
        int radius = (i % 2 == 0) ? size : size * sin(18 * deg) / cos(36 * deg);
        points[i].x = x + radius * cos(angle);
        points[i].y = y - radius * sin(angle);
    }
}

// Function to calculate the Euclidean distance between two points
double distance(gdPoint p1, gdPoint p2) {
    return sqrt(pow(p2.x - p1.x, 2) + pow(p2.y - p1.y, 2));
}

int main() {
    int width = 800;
    int height = 600;

    gdImagePtr img = gdImageCreateTrueColor(width, height);
    gdImageAlphaBlending(img, 0);

    FILE *outputFile = fopen("hellogd2.png", "wb");
    if (outputFile == NULL) {
        fprintf(stderr, "Error opening the output file.\n");
        return 1;
    }

    int red = gdImageColorAllocate(img, 255, 0, 0);

    gdPoint points[10];
    draw_star(img, 400, 60, 50, red, 0, points, 10);

    // Print distances between original vertices
    printf("Original Distances:\n");
    for (int i = 0; i < 10; i++) {
        printf("Vertex %d to Vertex %d: %lf\n", i, (i + 1) % 10, distance(points[i], points[(i + 1) % 10]));
    }
    
    // Call the rotation function and draw the star multiple times
    for (int i = 0; i < 12; i++) {
        rotateFilledPolygon(400, 300, 30, points, 10);
        gdImagePolygon(img, points, 10, red);

        // Print distances between rotated vertices
        printf("Rotated Distances %d:\n", i + 1);
        for (int j = 0; j < 10; j++) {
            printf("Vertex %d to Vertex %d: %lf\n", j, (j + 1) % 10, distance(points[j], points[(j + 1) % 10]));
        }
    }

    gdImagePngEx(img, outputFile, 9);
    fclose(outputFile);
    gdImageDestroy(img);

    return 0;
}
